"""
This is the template server side for ChatBot
"""
from bottle import route, run, template, static_file, request
import json
import requests
user_message = ""
server_answer = ""

@route('/', method='GET')
def index():
    return template("chatbot.html")

@route('/secret', method='GET')
def index():
    return template("secret.html")

@route("/chat", method='POST')
def chat():
    global user_message
    user_message= request.POST.get('msg')
    return

@route("/postanswer", method='POST')
def chat():
    global server_answer
    server_answer= request.POST.get('servermsg')
    return

@route("/getusermessage", method='GET')
def get():
    global user_message
    return user_message

@route("/getservermessage", method='GET')
def get():
    global server_answer
    return server_answer


@route('/js/<filename:re:.*\.js>', method='GET')
def javascripts(filename):
    return static_file(filename, root='js')


@route('/css/<filename:re:.*\.css>', method='GET')
def stylesheets(filename):
    return static_file(filename, root='css')


@route('/images/<filename:re:.*\.(jpg|png|gif|ico)>', method='GET')
def images(filename):
    return static_file(filename, root='images')


def main():
    run(host='localhost', port=7000)

if __name__ == '__main__':
    main()
